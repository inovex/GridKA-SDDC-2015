#!/bin/bash

while [ true ] ; do echo 'Hello GridKA' ; sleep 5 ; done